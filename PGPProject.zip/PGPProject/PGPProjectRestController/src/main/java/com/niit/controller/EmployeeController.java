package com.niit.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.niit.dao.EmployeeDAO;
import com.niit.models.Employee;

@RestController
@RequestMapping("/api/employee")
@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeController {
	@Autowired
	EmployeeDAO employeeDAO;

	@PostMapping
//	@RequestMapping("/addEmployee")
	public ResponseEntity<Void> addEmployee(@RequestBody Employee emp) {
		employeeDAO.addEmployee(emp);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	
	@GetMapping//("/getAllEmployees")
	public List<Employee> getAllEmployees()
	{
		System.out.println("In controller1");
		List<Employee> emp=employeeDAO.getAllEmployees();
		System.out.println("In controller2");
		return emp;
	}
	
	//@GetMapping("/getEmployeeById/{id}")
	@GetMapping("/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") int id) {
		if(employeeDAO.getEmployeeById(id)!=null)
			return new ResponseEntity<Employee>(employeeDAO.getEmployeeById(id),HttpStatus.OK);
		else
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
	}
	//@GetMapping("/getEmployeeByName/{name}")
	@GetMapping("/{name}")
	public ResponseEntity<Employee> getEmployeeByName(@PathVariable("name") String name) {
		if(employeeDAO.getEmployeeByName(name)!=null)
			return new ResponseEntity<Employee>(employeeDAO.getEmployeeByName(name),HttpStatus.OK);
		else
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
	}
	
	//@DeleteMapping("/deleteEmployee/{id}")
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteEmployee(@PathVariable("id") int id) {
		if(employeeDAO.getEmployeeById(id)!=null)
		{
			employeeDAO.deleteEmployee(id);
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		else
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	}
	
	@PutMapping
	//@RequestMapping("/updateEmployee")
	public ResponseEntity<Void> updateEmployee(@RequestBody Employee emp) {
		if(employeeDAO.getEmployeeById(emp.getId())!=null)
		{
			employeeDAO.updateEmployee(emp);
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		else
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	}
	
}

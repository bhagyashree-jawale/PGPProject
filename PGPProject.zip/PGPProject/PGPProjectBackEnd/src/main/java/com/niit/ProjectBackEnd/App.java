package com.niit.ProjectBackEnd;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.configuration.DBConfiguration;
import com.niit.dao.EmployeeDAO;
import com.niit.dao.EmployeeDAOImpl;
import com.niit.models.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        //CREATE SPRING CONTAINER , CONFIGURATION DETAILS TO THE CONTAINER
        ApplicationContext context=new AnnotationConfigApplicationContext(DBConfiguration.class,EmployeeDAOImpl.class);
        EmployeeDAO empDao=(EmployeeDAO)context.getBean("employeeDAOImpl");
///////////////////////////////////////////////////////////////////////////    

Employee emp=new Employee();
emp.setEmail("bhagya");
emp.setId(11);
emp.setName("bhagya");
emp.setPhone("4565467");
empDao.addEmployee(emp);

    }
}
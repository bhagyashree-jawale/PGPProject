package com.niit.dao;

import java.util.List;

import com.niit.models.Employee;


public interface EmployeeDAO {
	void addEmployee(Employee emp);
	Employee getEmployeeById(int id);
	Employee getEmployeeByName(String name);
	
	List<Employee> getAllEmployees();
	void deleteEmployee(int emp);
	void updateEmployee(Employee emp);
}

package com.niit.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.models.Employee;

@Repository("employeeDAOImpl")
@Transactional
public class EmployeeDAOImpl implements EmployeeDAO {

	@Autowired
	private SessionFactory sessionFactory;
	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(emp);
		//Session session=sessionFactory.getCurrentSession();
		//session.saveOrUpdate(emp);
	}
	@Override
	public Employee getEmployeeById(int id) {
		Session session=sessionFactory.getCurrentSession();
		Employee emp=(Employee)session.get(Employee.class, id);
		return emp;
	}
	@Override
	public Employee getEmployeeByName(String name) {
		Session session=sessionFactory.getCurrentSession();
		Employee emp=(Employee)session.get(Employee.class, name);
		return emp;
	}
	@Override
	public List<Employee> getAllEmployees() {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Employee");
		List<Employee> emp =query.list();
		return emp;
	}
	@Override
	public void deleteEmployee(int id) {
		Session session=sessionFactory.getCurrentSession();
		Employee emp =new Employee();
		emp.setId(id);
		session.delete(emp);
		
	}
	@Override
	public void updateEmployee(Employee emp) {
		sessionFactory.getCurrentSession().update(emp);		
	}

}
